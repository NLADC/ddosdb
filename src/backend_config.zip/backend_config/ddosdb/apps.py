from django.apps import AppConfig


class DdosdbConfig(AppConfig):
    name = 'ddosdb'
